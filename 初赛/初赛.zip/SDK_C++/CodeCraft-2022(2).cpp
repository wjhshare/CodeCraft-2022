#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <vector>
#include<algorithm>
#include <queue>
#include <time.h>

#define LOCALPATH
#define TESTOUTPUT
struct Client;
typedef struct Site{
    std::string mID;    //边缘节点ID
    int mbandwidth; //本边缘节点带宽上限
    int mAllocatedBand = 0;   //记录已分配带宽
    std::vector<Client*> mvLinkClient;    //与本边缘节点相连的客户节点ID（时延满足要求即视为相连）
    std::vector<bool> mvisLinkClient;
//    int  a   //qos连接的客户节点总数
//    int  b   //遍历到当前客户节点时已经有多少个客户节点使用了当前边缘节点
//    a - b
    std::priority_queue<int, std::vector<int>, std::greater<int>> mqPercent5; //在时序中，本边缘节点预被请求最高的5%次带宽
}Site;


typedef struct Client{
    std::string mID;
    std::vector<int> mvdemand;  //时序需求带宽, mvdemand[t]：表示 t 时刻本客户节点需求的带宽
    std::vector<Site*> mvLinkSite;  //与本客户节点相连的边缘节点（时延满足要求即视为相连）
    std::vector<int> mvLinkSiteIdx;
    int Allocateddemand = 0;
    //时序分配方案
    // mvsolution[t]：保存 t 时刻本客户节点将带宽分配给std::vector<std::pair<std::string, int>>个边缘节点，
    // 每个 pair 分别存储被本客户节点请求带宽 > 0 的边缘节点ID及被请求的带宽
    std::vector<std::vector<std::pair<std::string, int>>> mvsolution;
}Client;

typedef struct PathtInf{
    std::string configini;
    std::string demandcsv;
    std::string site_bandwidthcsv;
    std::string qoscsv;
    std::string solutiontxt;
} PathtInf;


bool cmpSite(Site* a, Site* b){
    return (a->mbandwidth - a->mAllocatedBand) < (b->mbandwidth - b->mAllocatedBand);
}

//读取config文件，并将键-值保存于Content中
bool ReadConfig(const std::string& filename, 
                std::map<std::string, int> &Content,
                const char* section);
    
//读取数据demand.csv，客户节点ID保存于 vClient， 时间名称保存于vTime
bool ReadData(const std::string& filename,
              std::vector<std::string>& vTime, 
              std::vector<Client>& vClient);

//读取数据 site_bandwidth.csv，将节点名保存到 vSiteID；带宽上限保存到 data 中, data[i] 即为 vSiteID[i] 的带宽上限
bool ReaSitedData(const std::string& filename,
                  std::vector<Site>& vSite);

//读取QoS文件，并保存于 data ，其中列表示客户节点，行表示边缘节点，data[i][j]表示 vSiteID[i]、vClientID[j] 的网络时延
bool ReadQos(const std::string& filename,
             std::vector<Client>& vClient, 
             std::vector<Site>& vSite, 
             int qos_upper);

//输出,vSolution[i][j][q] 表示 vTime[i], vClientID[j], vSiteID[q] 的请求带宽
bool WriteSolution(const std::string& filename, 
                   std::vector<std::string>& vTime,
                   std::vector<Client>& vClient);
bool InitialData(std::map<std::string, int>& mContent,
                 std::vector<std::string>& mvTime,
                 std::vector<Client>& mvClient,
                 std::vector<Site>& mvSite,
                 int& qos_upper,
                 PathtInf path);

int main() {
    clock_t start, finish;
    start = clock();
    PathtInf path;
#ifdef LOCALPATH
   path.configini = "./data/config.ini";
   path.demandcsv = "./data/demand.csv";
   path.site_bandwidthcsv = "./data/site_bandwidth.csv";
   path.qoscsv = "./data/qos.csv";
   path.solutiontxt = "/home/qunlou/huawei/SDK/SDK_C++/CodeCraft2022-charge-main/output/solution.txt";
#else
    path.configini = "/data/config.ini";
    path.demandcsv = "/data/demand.csv";
    path.site_bandwidthcsv = "/data/site_bandwidth.csv";
    path.qoscsv = "/data/qos.csv";
    path.solutiontxt = "/output/solution.txt";
#endif
    
    std::map<std::string, int> mContent;
    std::vector<std::string> mvTime;
    std::vector<Client> mvClient;   //结构体存储客户节点
    std::vector<Site> mvSite;
    int qos_upper;
    if(  ! InitialData(mContent,mvTime,mvClient,mvSite,qos_upper,path) ){
        std::cout<<"initial failed"<<std::endl;
        return;
    }
    
#ifdef TESTOUTPUT
    //用于测试的输出
    for(int t = 0; t < mvTime.size(); ++t) {
        for(int s = 0; s < mvSite.size(); ++s){
            mvSite[s].mAllocatedBand = 0;
        }

        for (int c = 0; c < mvClient.size(); ++c) {
            mvClient[c].Allocateddemand = 0;
            std::vector<std::pair<std::string, int>> cur_c_and_time;

            std::sort(mvClient[c].mvLinkSite.begin(), mvClient[c].mvLinkSite.end(), cmpSite);

            int avgdemand = mvClient[c].mvdemand[t]/mvClient[c].mvLinkSiteIdx.size();

            for(int sidx = 0; sidx < mvClient[c].mvLinkSite.size(); ++sidx){

                if(sidx == mvClient[c].mvLinkSiteIdx.size() - 1)
                    avgdemand = mvClient[c].mvdemand[t] - mvClient[c].Allocateddemand;

                if(mvClient[c].Allocateddemand + avgdemand > mvClient[c].mvdemand[t])
                    avgdemand = mvClient[c].mvdemand[t] - mvClient[c].Allocateddemand;

                if(avgdemand <= 0) continue;
                //判断边缘节点上限
                if(mvClient[c].mvLinkSite[sidx]->mAllocatedBand + avgdemand <= mvClient[c].mvLinkSite[sidx]->mbandwidth){
                    mvClient[c].mvLinkSite[sidx]->mAllocatedBand += avgdemand;
                    mvClient[c].Allocateddemand += avgdemand;
                    int ii = 0;
                    for(; ii < cur_c_and_time.size(); ++ii){
                        if(cur_c_and_time[ii].first == mvClient[c].mvLinkSite[sidx]->mID) {
                            cur_c_and_time[ii].second += avgdemand;
                            break;
                        }
                    }
                    if(ii >= cur_c_and_time.size())
                        cur_c_and_time.push_back(std::make_pair(mvClient[c].mvLinkSite[sidx]->mID, avgdemand));
                }
                //超出上限
                else{
                    int also = mvClient[c].mvLinkSite[sidx]->mbandwidth - mvClient[c].mvLinkSite[sidx]->mAllocatedBand;
                    mvClient[c].Allocateddemand += also;
                    mvClient[c].mvLinkSite[sidx]->mAllocatedBand += also;
                    cur_c_and_time.push_back(std::make_pair(mvClient[c].mvLinkSite[sidx]->mID, also));

                    if(sidx == mvClient[c].mvLinkSiteIdx.size() - 1) {
                        sidx = 0;
                        int avgnode = mvClient[c].mvLinkSite.size() - 1;
                        avgdemand += (avgdemand - also) / std::max(avgnode, 1);
                    }
                    else{
                        int avgnode = mvClient[c].mvLinkSite.size() - sidx;
                        avgdemand += (avgdemand - also)/std::max(avgnode, 1);
                    }
                }
            }
            mvClient[c].mvsolution.push_back(cur_c_and_time);
        }
    }

#else

#endif

    WriteSolution(path.solutiontxt, mvTime, mvClient);

    finish = clock();
    std::cout << "运行时间： " << (double)(finish - start) / CLOCKS_PER_SEC << std::endl;

	return 0;
}

bool InitialData(std::map<std::string, int>& mContent,
                 std::vector<std::string>& mvTime,
                 std::vector<Client>& mvClient,
                 std::vector<Site>& mvSite,
                 int& qos_upper,
                 PathtInf path){
    bool ret = true;
    ret = ret && ReadConfig(path.configini, mContent, "config");    //读取配置文件
    std::cout << mContent["qos_constraint"] << std::endl;
    qos_upper = mContent["qos_constraint"];

    ret = ret && ReadData(path.demandcsv, mvTime, mvClient);  //读取客户节点
    std::cout << "Time: " << mvTime[mvTime.size() - 1] << std::endl;
    std::cout << mvClient[mvClient.size() - 1].mID <<", " << mvClient[mvClient.size() - 1].mvdemand[0] << std::endl;

    ret = ret && ReaSitedData(path.site_bandwidthcsv, mvSite);  //读取边缘节点
    std::cout << "site id: " << mvSite[mvSite.size() - 1].mID <<" ,\t"
              <<"site bandwidth: " << mvSite[mvSite.size() - 1].mbandwidth << std::endl;

    ret = ret && ReadQos(path.qoscsv, mvClient, mvSite, qos_upper);  //读取QoS,并记录 client 和 site的连接关系
    std::cout << "边缘节点"<< mvSite[0].mID << "连接的客户节点数为： " << mvSite[0].mvLinkClient.size()
              << " ,\t" <<mvSite[0].mvLinkClient[0]->mID << std::endl; 
    return ret;
}

bool WriteSolution(const std::string& filename, 
                   std::vector<std::string>& vTime,
                   std::vector<Client>& vClient){
    std::ofstream solution(filename, std::ios::out);
    bool ret = true;
    if(!solution.is_open()){
        std::cout << "solution.txt flie open error" << std::endl;
        return false;
    }
    for(int t = 0; t < vTime.size(); ++t){
        for(int c = 0; c < vClient.size(); ++c){
            solution << vClient[c].mID <<":";
            bool begin_Client = true;
            for(int s = 0; s < vClient[c].mvsolution[t].size(); ++s){
                if(!begin_Client){
                    solution <<",";
                }
                solution << "<" << vClient[c].mvsolution[t][s].first << "," << vClient[c].mvsolution[t][s].second << ">";
                begin_Client = false;
            }
            if(t == vTime.size() - 1 && c == vClient.size() - 1) continue;  //去掉最后一行换行
            solution << std::endl;
        }
    }
    solution.close();
    return ret;
}

bool ReadQos(const std::string& filename,
             std::vector<Client>& vClient, 
             std::vector<Site>& vSite, 
             int qos_upper){
    bool ret = true;
    std::ifstream infile(filename.c_str());
    if (!infile)
    {
        std::cout << "QoS file open error!" << std::endl;
        ret = false;
        return ret;
    }

    std::string line;
    int pos;
    int site_idx = 0;
    getline(infile, line);  //  跳过第一行
    while(getline(infile, line)){
        //读取数据并保存在data中
        pos = line.find(",");
        line = line.substr(pos + 1);    //跳过第一个
        int client_idx = 0;
        pos = line.find(",");
        while(pos > -1){
            int cur_qos = stoi(line.substr(0, pos));
            if(cur_qos < qos_upper){
                vClient[client_idx].mvLinkSite.push_back(&vSite[site_idx]);
                vSite[site_idx].mvLinkClient.push_back(&vClient[client_idx]);

                vClient[client_idx].mvLinkSiteIdx.push_back(site_idx);
            }
            ++client_idx;
            line = line.substr(pos + 1);
            pos = line.find(",");
        }
        pos = line.find("\r"); //定位换行符
        int end_qos = stoi(line.substr(0, pos));
        if(end_qos < qos_upper){
            vClient[client_idx].mvLinkSite.push_back(&vSite[site_idx]);
            vSite[site_idx].mvLinkClient.push_back(&vClient[client_idx]);
            vClient[client_idx].mvLinkSiteIdx.push_back(site_idx);
        }
        ++site_idx;
    }
    infile.close();
    return ret;
}

bool ReadData(const std::string& filename,
              std::vector<std::string>& vTime, 
              std::vector<Client>& vClient)
{
    std::ifstream infile(filename.c_str());
    bool ret = true;
    if (!infile)
    {
        std::cout << "data file open error!" << std::endl;
        ret = false;
        return ret;
    }

    std::string line;
    int pos;

    getline(infile, line);
    pos = line.find("mtime,");
    line = line.substr(pos + 6);    //去掉mtime,
    //读取ClientID
    pos = line.find(",");
    while(pos > -1){
        Client cur;
        cur.mID = line.substr(0, pos);
        vClient.push_back(cur);
        line = line.substr(pos + 1);
        pos = line.find(",");
    }
    pos = line.find("\r"); //定位换行符

    Client end;
    end.mID = line.substr(0, pos);
    vClient.push_back(end);

    while(getline(infile, line)){
        //读取时间
        pos = line.find(",");
        vTime.push_back(line.substr(0, pos));
        line = line.substr(pos + 1);

        //读取客户需求的带宽数据并保存在data中
        int client_idx = 0;
        pos = line.find(",");
        while(pos > -1){
            vClient[client_idx].mvdemand.push_back(stoi(line.substr(0, pos)));
            ++client_idx;
            line = line.substr(pos + 1);
            pos = line.find(",");
        }
        pos = line.find("\r"); //定位换行符
        vClient[client_idx].mvdemand.push_back(stoi(line.substr(0, pos)));
    }
    infile.close();
    return ret;
}

bool ReadConfig(const std::string& filename, 
                std::map<std::string, int> &Content,
                const char* section){
    std::ifstream infile(filename.c_str());
    bool ret = true;
    if (!infile)
    {
        std::cout << "config file open error!" << std::endl;
        ret = false;
        return ret;
    }

    std::string line, key;
    int value;
    int pos = 0;
    std::string Tsection = std::string("[") + section + "]";
    bool flag = false;
    while (getline(infile, line))
    {
        //读取配置文件的section，即 [config]
        if(!flag)
        {
            pos = line.find(Tsection, 0);
            if(-1 == pos)
            {
                continue;
            }
            else
            {
                flag = true;
                getline(infile, line);
            }
        }

        pos = line.find("=");
        if(pos == -1 || line.find("#") == 0) continue;

        key = line.substr(0, pos);
        int endpos = line.find("\r\n");
        Content[key] = stoi(line.substr(pos + 1, endpos));
    }
    infile.close();
    return ret;
}

bool ReaSitedData(const std::string& filename,
                  std::vector<Site>& vSite){
    std::ifstream infile(filename.c_str());
    bool ret = true;
    if (!infile)
    {
        std::cout << "site_bandwidth file open error!" << std::endl;
        ret = false;
        return ret;
    }
    std::string line;
    int pos;
    getline(infile, line);  //读掉第一行

    while(getline(infile, line)){
        Site cur;
        //读取数据并保存在data中
        pos = line.find(",");
        cur.mID = line.substr(0, pos);

        line = line.substr(pos + 1);
        pos = line.find("\r"); //定位换行符
        cur.mbandwidth = stoi(line.substr(0, pos));
        vSite.push_back(cur);
    }
    infile.close();
    return ret;
}